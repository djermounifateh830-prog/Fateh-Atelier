import React, { useState } from 'react';
import {
  SuiviOF,
  LigneRetourOF,
  MouvementStock
} from '../../types';
import { StorageService } from '../../services/storage';
import {
  X,
  CheckCircle2,
  AlertTriangle,
  ClipboardCheck,
  RefreshCw,
  Info
} from 'lucide-react';

interface RetourOFModalProps {
  isOpen: boolean;
  suivi: SuiviOF;
  onClose: () => void;
  onCloture: () => void;
}

/**
 * Interprète ce que l'opérateur a écrit dans la colonne "Nouvelle Chute" :
 *  - vide            → CONFORME
 *  - commence par "BAR" → SUBSTITUTION barre neuve
 *  - nombre seul     → AJUSTEMENT dimension (chute abîmée)
 *  - autre texte     → SUBSTITUTION autre chute (référence)
 */
function interpreterSaisie(saisie: string): 'CONFORME' | 'BAR' | 'AJUSTEMENT' | 'AUTRE_CHUTE' {
  const s = saisie.trim().toUpperCase();
  if (!s) return 'CONFORME';
  if (s.startsWith('BAR')) return 'BAR';
  if (/^\d+$/.test(s)) return 'AJUSTEMENT';
  return 'AUTRE_CHUTE';
}

function BadgeSaisie({ saisie }: { saisie: string }) {
  const interp = interpreterSaisie(saisie);
  switch (interp) {
    case 'CONFORME':
      return <span className="text-[10px] bg-emerald-900/50 text-emerald-300 border border-emerald-600/40 px-1.5 py-0.5 rounded font-bold">✅ Conforme</span>;
    case 'BAR':
      return <span className="text-[10px] bg-sky-900/50 text-sky-300 border border-sky-600/40 px-1.5 py-0.5 rounded font-bold">🔄 Barre Neuve</span>;
    case 'AJUSTEMENT':
      return <span className="text-[10px] bg-amber-900/50 text-amber-300 border border-amber-600/40 px-1.5 py-0.5 rounded font-bold">✂️ Ajust. Dim.</span>;
    case 'AUTRE_CHUTE':
      return <span className="text-[10px] bg-purple-900/50 text-purple-300 border border-purple-600/40 px-1.5 py-0.5 rounded font-bold">🔀 Autre Chute</span>;
  }
}

export const RetourOFModal: React.FC<RetourOFModalProps> = ({
  isOpen,
  suivi,
  onClose,
  onCloture
}) => {
  const [lignes, setLignes] = useState<LigneRetourOF[]>(
    suivi.lignesRetour.map(l => ({ ...l }))
  );
  const [remarqueGlobale, setRemarqueGlobale] = useState<string>(suivi.remarqueGlobale || '');
  const [dateRetour, setDateRetour] = useState<string>(() => {
    const today = new Date();
    return `${String(today.getDate()).padStart(2,'0')}/${String(today.getMonth()+1).padStart(2,'0')}/${today.getFullYear()}`;
  });
  const [isConfirming, setIsConfirming] = useState<boolean>(false);

  if (!isOpen) return null;

  const updateLigne = (idx: number, field: keyof LigneRetourOF, value: string | number) => {
    setLignes(prev => {
      const next = [...prev];
      (next[idx] as any)[field] = value;
      return next;
    });
  };

  const handleConfirmerRetour = async () => {
    setIsConfirming(true);
    const now = new Date();
    const dateTimeStr = `${dateRetour} ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
    const mouvements: MouvementStock[] = [];
    let mvtIdx = 0;

    lignes.forEach(ligne => {
      const interp = interpreterSaisie(ligne.saisieOperateur);
      const makeId = () => `mvt-${Date.now()}-${mvtIdx++}`;

      if (interp === 'CONFORME') {
        // Sortie du support prévu
        mouvements.push({
          id: makeId(), date: dateTimeStr,
          type: ligne.typeSupport === 'BARRE_NEUVE' ? 'SORTIE_BARRE_NEUVE' : 'SORTIE_CHUTE',
          articleCode: ligne.articleCode,
          ofId: suivi.id, numCommande: suivi.numCommande, nomClient: suivi.nomClient,
          longueurMm: ligne.longueurPrevue, quantite: 1,
          remarque: `Conforme — Repère(s): ${ligne.repere}`
        });
        if (ligne.restePrevuMm > 0) {
          mouvements.push({
            id: makeId(), date: dateTimeStr, type: 'ENTREE_CHUTE',
            articleCode: ligne.articleCode,
            ofId: suivi.id, numCommande: suivi.numCommande, nomClient: suivi.nomClient,
            longueurMm: ligne.restePrevuMm, quantite: 1,
            remarque: `Chute stockée après coupe conforme — ${ligne.restePrevuMm}mm — Repère(s): ${ligne.repere}`
          });
        }
      } else if (interp === 'BAR') {
        // Substitution par barre neuve
        mouvements.push({
          id: makeId(), date: dateTimeStr, type: 'SORTIE_BARRE_NEUVE',
          articleCode: ligne.articleCode,
          ofId: suivi.id, numCommande: suivi.numCommande, nomClient: suivi.nomClient,
          longueurMm: ligne.longueurPrevue, quantite: 1,
          remarque: `Substitution barre neuve (chute non trouvée) — Repère(s): ${ligne.repere}`
        });
        if (ligne.typeSupport === 'CHUTE_BARRE') {
          // Libérer la chute prévue non utilisée
          mouvements.push({
            id: makeId(), date: dateTimeStr, type: 'ENTREE_CHUTE',
            articleCode: ligne.articleCode,
            ofId: suivi.id, numCommande: suivi.numCommande, nomClient: suivi.nomClient,
            longueurMm: ligne.longueurPrevue, quantite: 1,
            remarque: `Chute ${ligne.longueurPrevue}mm libérée — remplacée par barre neuve`
          });
        }
        if (ligne.residuBarreNeuve && ligne.residuBarreNeuve > 0) {
          mouvements.push({
            id: makeId(), date: dateTimeStr, type: 'ENTREE_CHUTE',
            articleCode: ligne.articleCode,
            ofId: suivi.id, numCommande: suivi.numCommande, nomClient: suivi.nomClient,
            longueurMm: ligne.residuBarreNeuve, quantite: 1,
            remarque: `Résidu barre neuve — ${ligne.residuBarreNeuve}mm — Repère(s): ${ligne.repere}`
          });
        }
      } else if (interp === 'AJUSTEMENT') {
        // Chute abîmée → nouvelle dimension
        const nouvelleDim = parseInt(ligne.saisieOperateur.trim(), 10);
        mouvements.push({
          id: makeId(), date: dateTimeStr, type: 'AJUSTEMENT_CHUTE',
          articleCode: ligne.articleCode,
          ofId: suivi.id, numCommande: suivi.numCommande, nomClient: suivi.nomClient,
          longueurMm: nouvelleDim, quantite: 1,
          remarque: `Chute abîmée ajustée: ${ligne.longueurPrevue}mm → ${nouvelleDim}mm — Repère(s): ${ligne.repere}`
        });
      } else {
        // Autre chute utilisée en substitution
        mouvements.push({
          id: makeId(), date: dateTimeStr, type: 'SORTIE_CHUTE',
          articleCode: ligne.articleCode,
          ofId: suivi.id, numCommande: suivi.numCommande, nomClient: suivi.nomClient,
          longueurMm: ligne.longueurPrevue, quantite: 1,
          remarque: `Chute substituée par "${ligne.saisieOperateur.trim()}" — Repère(s): ${ligne.repere}`
        });
        if (ligne.typeSupport === 'CHUTE_BARRE') {
          mouvements.push({
            id: makeId(), date: dateTimeStr, type: 'ENTREE_CHUTE',
            articleCode: ligne.articleCode,
            ofId: suivi.id, numCommande: suivi.numCommande, nomClient: suivi.nomClient,
            longueurMm: ligne.longueurPrevue, quantite: 1,
            remarque: `Chute ${ligne.longueurPrevue}mm libérée (substituée par ${ligne.saisieOperateur.trim()})`
          });
        }
        if (ligne.restePrevuMm > 0) {
          mouvements.push({
            id: makeId(), date: dateTimeStr, type: 'ENTREE_CHUTE',
            articleCode: ligne.articleCode,
            ofId: suivi.id, numCommande: suivi.numCommande, nomClient: suivi.nomClient,
            longueurMm: ligne.restePrevuMm, quantite: 1,
            remarque: `Résidu après coupe sur chute ${ligne.saisieOperateur.trim()} — ${ligne.restePrevuMm}mm`
          });
        }
      }
    });

    try {
      await StorageService.closeOF({
        ...suivi,
        statut: 'CLOTURE',
        dateRetour,
        lignesRetour: lignes,
        remarqueGlobale
      }, mouvements);
    } catch (error: any) {
      setIsConfirming(false);
      alert(`Impossible de clôturer l'OF : ${error.message}`);
      return;
    }

    setIsConfirming(false);
    onCloture();
    onClose();
  };

  const nbConformes = lignes.filter(l => interpreterSaisie(l.saisieOperateur) === 'CONFORME').length;
  const nbCorrections = lignes.length - nbConformes;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-5xl max-h-[96vh] flex flex-col shadow-2xl text-slate-100 overflow-hidden">

        {/* Header */}
        <div className="px-5 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-sky-600 flex items-center justify-center">
              <ClipboardCheck className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                Retour OF — Saisie des Corrections Opérateur
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-mono font-bold">
                  {suivi.numCommande}
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                {suivi.nomClient} • {suivi.titreSection} • Émis le {suivi.dateEmission}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Guide de saisie */}
        <div className="mx-5 mt-4 p-3 bg-slate-800/60 border border-slate-700 rounded-xl text-xs text-slate-300">
          <div className="font-bold text-slate-100 flex items-center gap-1.5 mb-2">
            <Info className="w-3.5 h-3.5 text-sky-400" />
            Transcrivez ce que l'opérateur a écrit dans "Nouvelle Chute" sur le papier :
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
            <div className="bg-emerald-900/30 border border-emerald-700/30 rounded px-2 py-1">
              <span className="font-bold text-emerald-300">Vide</span> → Conforme, rien à changer
            </div>
            <div className="bg-sky-900/30 border border-sky-700/30 rounded px-2 py-1">
              <span className="font-bold text-sky-300">BAR</span> → Barre neuve utilisée à la place
            </div>
            <div className="bg-amber-900/30 border border-amber-700/30 rounded px-2 py-1">
              <span className="font-bold text-amber-300">1250</span> → Chute abîmée, reste 1250mm
            </div>
            <div className="bg-purple-900/30 border border-purple-700/30 rounded px-2 py-1">
              <span className="font-bold text-purple-300">C-22</span> → Autre chute utilisée
            </div>
          </div>
        </div>

        {/* Tableau des lignes */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
          <div className="text-xs text-slate-400">
            {lignes.length} ligne(s) —{' '}
            <span className="text-emerald-400">{nbConformes} conforme(s)</span> —{' '}
            <span className="text-amber-400">{nbCorrections} correction(s)</span>
          </div>

          <div className="border border-slate-700 rounded-xl overflow-x-auto">
            <table className="w-full text-xs border-collapse min-w-[700px]">
              <thead className="bg-slate-800 text-slate-300 font-bold">
                <tr>
                  <th className="py-2 px-3 text-left border-r border-slate-700 w-28">Support Prévu</th>
                  <th className="py-2 px-3 text-left border-r border-slate-700">Repère(s)</th>
                  <th className="py-2 px-3 text-center border-r border-slate-700 w-24">Dim. Prévue</th>
                  <th className="py-2 px-3 text-center border-r border-slate-700 w-24">Reste Prévu</th>
                  <th className="py-2 px-3 text-left border-r border-slate-700 w-40">
                    Nouvelle Chute <span className="text-amber-400 font-normal">(papier)</span>
                  </th>
                  <th className="py-2 px-3 text-center border-r border-slate-700 w-28">Résidu BAR</th>
                  <th className="py-2 px-3 text-left border-r border-slate-700 w-32">Interprétation</th>
                  <th className="py-2 px-3 text-left">Remarque</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {lignes.map((ligne, idx) => {
                  const interp = interpreterSaisie(ligne.saisieOperateur);
                  return (
                    <tr key={ligne.id} className={`${idx % 2 === 0 ? 'bg-slate-900' : 'bg-slate-950/50'} hover:bg-slate-800/30 transition`}>
                      <td className="py-2 px-3 border-r border-slate-800">
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                          ligne.typeSupport === 'BARRE_NEUVE'
                            ? 'bg-emerald-900/40 text-emerald-300 border-emerald-700/40'
                            : 'bg-sky-900/40 text-sky-300 border-sky-700/40'
                        }`}>
                          {ligne.typeSupport === 'BARRE_NEUVE' ? '🪵 Barre Neuve' : '📦 Chute Stock'}
                        </span>
                      </td>
                      <td className="py-2 px-3 border-r border-slate-800 font-mono text-amber-300 font-bold text-[11px]">
                        {ligne.repere}
                      </td>
                      <td className="py-2 px-3 border-r border-slate-800 text-center font-mono font-bold text-slate-200">
                        {ligne.longueurPrevue} mm
                      </td>
                      <td className="py-2 px-3 border-r border-slate-800 text-center font-mono text-slate-400">
                        {ligne.restePrevuMm > 0 ? `${ligne.restePrevuMm} mm` : '—'}
                      </td>
                      <td className="py-2 px-3 border-r border-slate-800">
                        <input
                          type="text"
                          value={ligne.saisieOperateur}
                          onChange={e => updateLigne(idx, 'saisieOperateur', e.target.value)}
                          placeholder="vide si conforme…"
                          className="w-full bg-slate-800 border border-slate-600 rounded px-2 py-1 font-mono text-xs text-slate-100 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400/30 placeholder:text-slate-600"
                        />
                      </td>
                      <td className="py-2 px-3 border-r border-slate-800">
                        {interp === 'BAR' ? (
                          <input
                            type="number"
                            value={ligne.residuBarreNeuve ?? ''}
                            onChange={e => updateLigne(idx, 'residuBarreNeuve', parseInt(e.target.value, 10) || 0)}
                            placeholder="mm résidu"
                            className="w-full bg-sky-900/30 border border-sky-600/50 rounded px-2 py-1 font-mono text-xs text-sky-200 focus:outline-none focus:border-sky-400"
                          />
                        ) : (
                          <span className="text-slate-600 text-center block">—</span>
                        )}
                      </td>
                      <td className="py-2 px-3 border-r border-slate-800">
                        <BadgeSaisie saisie={ligne.saisieOperateur} />
                      </td>
                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={ligne.remarque || ''}
                          onChange={e => updateLigne(idx, 'remarque', e.target.value)}
                          placeholder="Remarque…"
                          className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs text-slate-300 focus:outline-none focus:border-slate-500"
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Remarque générale + date retour */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2 space-y-1">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                Remarque générale de l'opérateur (bas du papier)
              </label>
              <textarea
                value={remarqueGlobale}
                onChange={e => setRemarqueGlobale(e.target.value)}
                placeholder="ex: Chute C-14 introuvable. Cherché dans zone B. Utilisé barre neuve."
                rows={2}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400 resize-none"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Date de retour</label>
              <input
                type="text"
                value={dateRetour}
                onChange={e => setDateRetour(e.target.value)}
                placeholder="DD/MM/YYYY"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 font-mono text-xs text-slate-200 focus:outline-none focus:border-slate-500"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-3 flex-wrap">
          <div className="text-xs">
            {nbCorrections > 0
              ? <span className="text-amber-400 font-semibold">{nbCorrections} correction(s) à appliquer au stock</span>
              : <span className="text-emerald-400 font-semibold">✅ Tout conforme — Stock mis à jour tel que prévu</span>
            }
          </div>
          <div className="flex items-center gap-2">
            <button type="button" onClick={onClose}
              className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg transition cursor-pointer">
              Annuler
            </button>
            <button type="button" onClick={handleConfirmerRetour} disabled={isConfirming}
              className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white text-xs font-black rounded-lg flex items-center gap-2 transition shadow-lg shadow-emerald-500/20 cursor-pointer">
              {isConfirming
                ? <RefreshCw className="w-4 h-4 animate-spin" />
                : <CheckCircle2 className="w-4 h-4" />
              }
              <span>Confirmer le Retour &amp; Clôturer l'OF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
