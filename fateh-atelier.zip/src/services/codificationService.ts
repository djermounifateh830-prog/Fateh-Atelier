export interface InfoAgence {
  code: string;
  nom: string;
  type: 'SOMADAL' | 'CRISTAL' | 'ATELIER' | 'AUTRE';
  badgeColor: string;
  badgeBg: string;
  description: string;
}

export function detecterAgence(refCommande: string): InfoAgence {
  const ref = (refCommande || '').trim().toUpperCase();

  if (ref.startsWith('S-A') || ref.startsWith('SA')) {
    return {
      code: 'SOMADAL-ALGER',
      nom: 'SOMADAL Alger',
      type: 'SOMADAL',
      badgeColor: 'text-sky-300',
      badgeBg: 'bg-sky-500/20 border-sky-500/30',
      description: 'Client Pro / Menuisiers & Promoteurs (Alger)'
    };
  }
  if (ref.startsWith('S-O') || ref.startsWith('SO')) {
    return {
      code: 'SOMADAL-ORAN',
      nom: 'SOMADAL Oran',
      type: 'SOMADAL',
      badgeColor: 'text-sky-300',
      badgeBg: 'bg-sky-500/20 border-sky-500/30',
      description: 'Client Pro / Menuisiers & Promoteurs (Oran)'
    };
  }
  if (ref.startsWith('S-C') || ref.startsWith('SC')) {
    return {
      code: 'SOMADAL-CONST',
      nom: 'SOMADAL Constantine',
      type: 'SOMADAL',
      badgeColor: 'text-sky-300',
      badgeBg: 'bg-sky-500/20 border-sky-500/30',
      description: 'Client Pro / Menuisiers & Promoteurs (Constantine)'
    };
  }

  if (ref.startsWith('C-A') || ref.startsWith('CA')) {
    return {
      code: 'CRISTAL-ALGER',
      nom: 'CRISTAL Alger',
      type: 'CRISTAL',
      badgeColor: 'text-purple-300',
      badgeBg: 'bg-purple-500/20 border-purple-500/30',
      description: 'Showroom Particuliers & Habitat (Alger)'
    };
  }
  if (ref.startsWith('C-O') || ref.startsWith('CO')) {
    return {
      code: 'CRISTAL-ORAN',
      nom: 'CRISTAL Oran',
      type: 'CRISTAL',
      badgeColor: 'text-purple-300',
      badgeBg: 'bg-purple-500/20 border-purple-500/30',
      description: 'Showroom Particuliers & Habitat (Oran)'
    };
  }
  if (ref.startsWith('C-C') || ref.startsWith('CC')) {
    return {
      code: 'CRISTAL-CONST',
      nom: 'CRISTAL Constantine',
      type: 'CRISTAL',
      badgeColor: 'text-purple-300',
      badgeBg: 'bg-purple-500/20 border-purple-500/30',
      description: 'Showroom Particuliers & Habitat (Constantine)'
    };
  }

  if (ref.startsWith('AO') || ref.startsWith('A26') || ref.startsWith('A-')) {
    return {
      code: 'ATELIER-ALGER',
      nom: 'ATELIER Alger (Sous-traitance)',
      type: 'ATELIER',
      badgeColor: 'text-amber-300',
      badgeBg: 'bg-amber-500/20 border-amber-500/30',
      description: 'Sous-traitance inter-ateliers (Semi-fini / Débit)'
    };
  }

  if (ref.startsWith('OO') || ref.startsWith('O-')) {
    return {
      code: 'ATELIER-ORAN',
      nom: 'ATELIER Oran (Sous-traitance)',
      type: 'ATELIER',
      badgeColor: 'text-amber-300',
      badgeBg: 'bg-amber-500/20 border-amber-500/30',
      description: 'Sous-traitance inter-ateliers (Oran)'
    };
  }

  if (ref.startsWith('CO') || ref.startsWith('C-')) {
    return {
      code: 'ATELIER-CONST',
      nom: 'ATELIER Constantine (Sous-traitance)',
      type: 'ATELIER',
      badgeColor: 'text-amber-300',
      badgeBg: 'bg-amber-500/20 border-amber-500/30',
      description: 'Sous-traitance inter-ateliers (Constantine)'
    };
  }

  return {
    code: 'STANDARD',
    nom: 'Commande Client',
    type: 'AUTRE',
    badgeColor: 'text-emerald-300',
    badgeBg: 'bg-emerald-500/20 border-emerald-500/30',
    description: 'Commande standard'
  };
}

export const LISTE_DONNEURS_ORDRE = [
  { id: 'SOMADAL-ALGER', nom: 'SOMADAL Alger', prefix: 'S-A', type: 'SOMADAL', badge: 'bg-sky-500/20 text-sky-300 border-sky-500/30', desc: 'Menuisiers & Promoteurs (Alger)' },
  { id: 'SOMADAL-ORAN', nom: 'SOMADAL Oran', prefix: 'S-O', type: 'SOMADAL', badge: 'bg-sky-500/20 text-sky-300 border-sky-500/30', desc: 'Menuisiers & Promoteurs (Oran)' },
  { id: 'SOMADAL-CONST', nom: 'SOMADAL Constantine', prefix: 'S-C', type: 'SOMADAL', badge: 'bg-sky-500/20 text-sky-300 border-sky-500/30', desc: 'Menuisiers & Promoteurs (Constantine)' },
  { id: 'CRISTAL-ALGER', nom: 'CRISTAL Alger', prefix: 'C-A', type: 'CRISTAL', badge: 'bg-purple-500/20 text-purple-300 border-purple-500/30', desc: 'Particuliers & Showroom (Alger)' },
  { id: 'CRISTAL-ORAN', nom: 'CRISTAL Oran', prefix: 'C-O', type: 'CRISTAL', badge: 'bg-purple-500/20 text-purple-300 border-purple-500/30', desc: 'Particuliers & Showroom (Oran)' },
  { id: 'CRISTAL-CONST', nom: 'CRISTAL Constantine', prefix: 'C-C', type: 'CRISTAL', badge: 'bg-purple-500/20 text-purple-300 border-purple-500/30', desc: 'Particuliers & Showroom (Constantine)' },
  { id: 'ATELIER-ALGER', nom: 'ATELIER Alger (Sous-traitance)', prefix: 'AO', type: 'ATELIER', badge: 'bg-amber-500/20 text-amber-300 border-amber-500/30', desc: 'Sous-traitance inter-ateliers (Alger)' },
  { id: 'ATELIER-ORAN', nom: 'ATELIER Oran (Sous-traitance)', prefix: 'OO', type: 'ATELIER', badge: 'bg-amber-500/20 text-amber-300 border-amber-500/30', desc: 'Sous-traitance inter-ateliers (Oran)' },
  { id: 'ATELIER-CONST', nom: 'ATELIER Constantine (Sous-traitance)', prefix: 'CO', type: 'ATELIER', badge: 'bg-amber-500/20 text-amber-300 border-amber-500/30', desc: 'Sous-traitance inter-ateliers (Constantine)' },
  { id: 'CLIENT-DIRECT', nom: 'Client Direct / Menuisier Partenaire', prefix: 'CMD', type: 'AUTRE', badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30', desc: 'Commande directe atelier' }
];

export function getTodayDateString(): string {
  const d = new Date();
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}/${month}/${year}`;
}
