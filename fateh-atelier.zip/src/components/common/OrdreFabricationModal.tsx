import React, { useMemo, useState } from 'react';
import { ResultatOptimisation, Article, PieceCoupee, BesoinMoustiquaire, SuiviOF, LigneRetourOF, FamilleProduit } from '../../types';
import { detecterAgence } from '../../services/codificationService';
import { calculerBesoinMaille } from '../../services/moteurMoustiquaire';
import { StorageService } from '../../services/storage';

import { getTodayDateString } from '../../services/codificationService';
import { X, Printer, Download, Send, CheckCircle2 } from 'lucide-react';

export interface SectionDebitOF {
  id?: string;
  titreSection: string;
  article: Article | null;
  resultat: ResultatOptimisation;
  coloris?: string;
  badge?: string;
  avecPeinture?: boolean;
  avecSousFace?: boolean;
  montageSousFace?: string;
  isSousFace?: boolean;
}

interface OrdreFabricationModalProps {
  isOpen: boolean;
  onClose: () => void;
  titreProduit?: string;
  refCommande: string;
  nomClient?: string;
  dateCommande?: string;
  coloris?: string;
  article?: Article | null;
  resultat?: ResultatOptimisation | null;
  sections?: SectionDebitOF[];
  lignesMoustiquaires?: BesoinMoustiquaire[];
  famille?: FamilleProduit;
  donneurOrdre?: string;
}

interface GroupeBarreNeuve {
  quantite: number;
  longueurBarre: number;
  pieces: PieceCoupee[];
  utilise: number;
  chute: number;
  statut: 'Dechet' | 'STOCK' | 'SACRIFICE';
  barreIndices: number[];
}

interface GroupeChuteRecup {
  quantite: number;
  support: number;
  pieces: PieceCoupee[];
  utilise: number;
  reste: number;
  chuteIndices: number[];
}

interface SectionTraitee {
  titre: string;
  badge?: string;
  article: Article | null;
  resultat: ResultatOptimisation;
  barreLongueur: number;
  lameScie: number;
  margeDebord: number;
  avecPeinture: boolean;
  avecSousFace: boolean;
  montageSousFace: string;
  isSousFace: boolean;
  groupesBarresNeuves: GroupeBarreNeuve[];
  groupesChutesRecup: GroupeChuteRecup[];
}

export const OrdreFabricationModal: React.FC<OrdreFabricationModalProps> = ({
  isOpen,
  onClose,
  titreProduit = 'Fiche de Coupe',
  refCommande,
  nomClient,
  dateCommande,
  coloris = '',
  article = null,
  resultat = null,
  sections,
  lignesMoustiquaires = [],
  famille = 'CAISSON',
  donneurOrdre = ''
}) => {
  // ⚠️ Hooks React AVANT tout return conditionnel (règle absolue de React)
  const [ofEmis, setOfEmis] = useState<boolean>(false);
  const [isEmitting, setIsEmitting] = useState<boolean>(false);

  // Guard : ne rien rendre si le modal est fermé
  if (!isOpen) return null;

  const formaterCoupe = (p: PieceCoupee) => {
    const lg = Math.round(p.longueur);
    const rep = p.repere || p.label || '';
    if (!rep) return `${lg} mm`;
    return `${lg} mm — Repère : ${rep}`;
  };

  const labelFinition = (avecPeinture: boolean) =>
    avecPeinture ? 'AVEC PEINTURE' : 'SANS PEINTURE';

  const labelMontage = (avecSousFace: boolean, montage: string) => {
    if (!avecSousFace) return '';
    return montage === 'MONTEE_ATELIER' ? 'AVEC MONTAGE' : 'SANS MONTAGE';
  };

  const listeSections: SectionTraitee[] = useMemo(() => {
    let rawSections: SectionDebitOF[] = [];

    if (sections && sections.length > 0) {
      rawSections = sections.filter(s => s && s.resultat);
    } else if (resultat) {
      rawSections = [{ titreSection: titreProduit, article, resultat, coloris }];
    }

    return rawSections.map((sec, idx) => {
      const res = sec.resultat;
      const art = sec.article;
      const barresNeuves = Array.isArray(res.barres_neuves) ? res.barres_neuves : [];
      const chutesUtilisees = Array.isArray(res.chutes_utilisees) ? res.chutes_utilisees : [];

      const barreLongueur = art?.longeur || barresNeuves[0]?.longueur_barre || 6000;
      const lameScie = art?.lame || 4.0;
      const margeDebord = art?.debordement || 0.0;

      // Groupement BARRES NEUVES
      const mapBarres = new Map<string, GroupeBarreNeuve>();
      barresNeuves.forEach((b, bIdx) => {
        const pieces = Array.isArray(b.pieces) ? b.pieces : [];
        const sig = pieces.map(p => `${Math.round(p.longueur)}_${p.repere || p.label}`).join('|');
        if (!mapBarres.has(sig)) {
          mapBarres.set(sig, { quantite: 0, longueurBarre: b.longueur_barre, pieces, utilise: b.utilise, chute: b.chute, statut: b.statut, barreIndices: [] });
        }
        const g = mapBarres.get(sig)!;
        g.quantite += 1;
        g.barreIndices.push(bIdx + 1);
      });
      const groupesBarresNeuves = Array.from(mapBarres.values()).sort((a, b) => b.quantite - a.quantite);

      // Groupement CHUTES RÉCUPÉRÉES
      const mapChutes = new Map<string, GroupeChuteRecup>();
      chutesUtilisees.forEach((c, cIdx) => {
        const pieces = Array.isArray(c.pieces) ? c.pieces : [];
        const sig = `${Math.round(c.longueur_chute_depart)}:` + pieces.map(p => `${Math.round(p.longueur)}_${p.repere || p.label}`).join('|');
        if (!mapChutes.has(sig)) {
          mapChutes.set(sig, { quantite: 0, support: c.longueur_chute_depart, pieces, utilise: c.utilise, reste: c.reste, chuteIndices: [] });
        }
        const g = mapChutes.get(sig)!;
        g.quantite += 1;
        g.chuteIndices.push(cIdx + 1);
      });
      const groupesChutesRecup = Array.from(mapChutes.values()).sort((a, b) => b.support - a.support);

      const titreBrut = sec.titreSection || art?.designation || `Poste ${idx + 1}`;
      const titrePropre = titreBrut.replace(/\s*\([^)]*\)/g, '').trim();
      const isSousFaceDetected = !!sec.isSousFace || sec.badge === 'SOUS-FACE' || titreBrut.includes('SF') || titreBrut.includes('Sous-Face');

      return {
        titre: titrePropre,
        badge: sec.badge,
        article: art,
        resultat: res,
        barreLongueur,
        lameScie,
        margeDebord,
        avecPeinture: !!sec.avecPeinture,
        avecSousFace: !!sec.avecSousFace,
        montageSousFace: sec.montageSousFace || 'NON_MONTEE',
        isSousFace: isSousFaceDetected,
        groupesBarresNeuves,
        groupesChutesRecup
      };
    });
  }, [sections, resultat, article, titreProduit, coloris]);

  if (listeSections.length === 0) return null;

  const clientAffiche = nomClient || 'CLIENT';
  const cmdAffichee = refCommande || 'S-A26736';
  const dateAffichee = dateCommande || new Date().toLocaleDateString('fr-FR');
  const agenceInfo = detecterAgence(cmdAffichee);

  const totalBarresNeuvesToutesSections = listeSections.reduce((s, sec) => s + (sec.resultat.total_barres_neuves || 0), 0);
  const totalChutesRecycleesToutesSections = listeSections.reduce((s, sec) => s + (sec.resultat.total_chutes_recyclees || 0), 0);
  const totalStockableMm = listeSections.reduce((s, sec) => s + (sec.resultat.total_chute_mm || 0), 0);
  const totalDechetMm = listeSections.reduce((s, sec) => s + (sec.resultat.total_dechet_mm || 0), 0);

  /* ─── SECTION HTML POUR EXPORT ─────────────────────────────── */
  const buildSectionHTML = (sec: SectionTraitee, secIdx: number) => {
    const isCaissonSection = sec.titre.toUpperCase().includes('CAISSON');
    const conditionsHtml = isCaissonSection ? [
      labelFinition(sec.avecPeinture),
      sec.avecSousFace ? labelMontage(sec.avecSousFace, sec.montageSousFace) : ''
    ].filter(Boolean).join(' | ') : '';

    const barresHTML = sec.groupesBarresNeuves.map(g => `
      <tr>
        <td class="qte">${g.quantite}</td>
        <td class="cuts">${g.pieces.map(p => `<div class="cut-line">${formaterCoupe(p)}</div>`).join('')}</td>
        <td class="num">${Math.round(g.chute)}</td>
        <td class="statut ${g.statut === 'STOCK' ? 'stock' : ''}">${g.statut === 'STOCK' ? 'A STOCKER' : 'DECHET'}</td>
        <td class="trace-cell">Nouvelle chute : ................................</td>
      </tr>`).join('');

    const chutesHTML = sec.groupesChutesRecup.map(g => `
      <tr>
        <td class="qte" style="color:#1d4ed8;">${g.quantite}</td>
        <td class="support">${Math.round(g.support)} mm</td>
        <td class="cuts">${g.pieces.map(p => `<div class="cut-line">${formaterCoupe(p)}</div>`).join('')}</td>
        <td class="num">${Math.round(g.reste)}</td>
        <td class="trace-cell">Nouvelle chute : ................................</td>
      </tr>`).join('');

    return `
    <div class="section-container" style="${secIdx > 0 ? 'margin-top:20px;padding-top:15px;border-top:2px dashed #94a3b8;page-break-inside:avoid;' : ''}">
      <div class="meta-section-bar">
        <div class="section-title-box">${sec.titre}${conditionsHtml ? ` — ${conditionsHtml}` : ''}</div>
      </div>
      ${sec.groupesBarresNeuves.length > 0 ? `
      <div class="sub-title">COUPES SUR BARRES NEUVES (${sec.resultat.total_barres_neuves} barre(s))</div>
      <table>
        <thead><tr>
          <th style="width:50px;text-align:center;">Qté</th>
          <th>Mesures à Couper (avec Repère)</th>
          <th style="width:70px;text-align:center;">Reste</th>
          <th style="width:90px;text-align:center;">Ce reste</th>
          <th style="width:180px;">Nouvelle chute</th>
        </tr></thead>
        <tbody>${barresHTML}</tbody>
      </table>` : ''}
      ${sec.groupesChutesRecup.length > 0 ? `
      <div class="sub-title">COUPES SUR CHUTES DU STOCK (${sec.resultat.total_chutes_recyclees} chute(s))</div>
      <table>
        <thead><tr>
          <th style="width:50px;text-align:center;">Qté</th>
          <th style="width:90px;text-align:center;">Chute prévue</th>
          <th>Mesures à Couper (avec Repère)</th>
          <th style="width:70px;text-align:center;">Reste</th>
          <th style="width:180px;">Nouvelle chute</th>
        </tr></thead>
        <tbody>${chutesHTML}</tbody>
      </table>` : ''}
    </div>`;
  };

  const handleDownloadHTML = () => {
    const mailleHTML = (lignesMoustiquaires && lignesMoustiquaires.filter(m => m.typeFabrication !== 'PROFILES_SEULS').length > 0) ? `
    <div class="section-container" style="page-break-inside:avoid;margin-bottom:16px;">
      <div class="meta-section-bar">
        <div class="section-title-box">🕸️ 1. DÉBIT &amp; FAÇONNAGE MAILLE MSTQ (TOILE PLISSÉE)</div>
      </div>
      <table>
        <thead>
          <tr>
            <th style="width:60px;text-align:center;">Repère</th>
            <th>Dim. Finie (L × H)</th>
            <th>Type Ouverture</th>
            <th style="text-align:center;">Coupe Fixe Maille</th>
            <th style="text-align:center;">Nb Plis (+2 sécu)</th>
            <th>Guidage &amp; Cordelettes</th>
            <th style="text-align:center;">Surface</th>
            <th>Article Maille MSTQ</th>
          </tr>
        </thead>
        <tbody>
          ${lignesMoustiquaires.filter(m => m.typeFabrication !== 'PROFILES_SEULS').map(m => {
            const c = calculerBesoinMaille(m);
            return `<tr>
              <td style="text-align:center;font-weight:900;color:#b45309;">${m.repere}</td>
              <td style="font-weight:bold;">${m.largeur} × ${m.hauteur} mm (×${m.quantite})</td>
              <td>${m.typeOuverture === 'PORTE_FENETRE' ? 'Porte-Fenêtre' : m.typeOuverture === 'DOUBLE_VANTAUX' ? 'Baie 2 Vtx' : m.typeOuverture === 'CENTRALE' ? 'Centrale' : m.typeOuverture === 'FIXE' ? 'Fixe' : 'Fenêtre'}</td>
              <td style="text-align:center;font-weight:bold;color:#b45309;">${c.dimension_fixe_requise} mm (${c.dimension_fixe_est === 'H' ? 'Hauteur' : 'Largeur'})</td>
              <td style="text-align:center;font-weight:900;color:#047857;">${c.nb_plis_requis} plis</td>
              <td>${c.nb_fils_guidage} fils (~${c.distance_cordes}mm) • Corde : <strong>${c.longueur_corde_totale_m}m</strong> (${c.longueur_corde_unitaire_m}m/fil)</td>
              <td style="text-align:center;">${c.superficie_m2} m²</td>
              <td style="font-size:10px;">${m.articleDesignationMaille || 'MSTQ MAILLE PLISSÉE 20mm'}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>` : '';

    const sectionsHTML = listeSections.map((sec, idx) => buildSectionHTML(sec, idx)).join('');
    const htmlContent = `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Ordre de Fabrication — ${cmdAffichee} — ${clientAffiche}</title>
  <style>
    @page { size: A4 portrait; margin: 10mm; }
    body { font-family: Arial, Helvetica, sans-serif; margin: 0; padding: 10px; color: #000; background: #fff; font-size: 12px; }
    .header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:10px; border-bottom:2px solid #000; padding-bottom:6px; }
    .header-left h1 { font-size:17px; font-weight:900; margin:0 0 3px 0; text-transform:uppercase; }
    .header-left .meta { font-size:11px; color:#222; }
    .logo-m { font-size:22px; font-weight:900; color:#1e3a8a; }
    .logo-text { font-size:9px; font-weight:bold; letter-spacing:1px; color:#333; }
    .client-info-bar { display:flex; justify-content:space-between; background:#f1f5f9; padding:6px 10px; border:1px solid #cbd5e1; font-size:11px; margin-bottom:12px; font-weight:bold; }
    .meta-section-bar { display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; }
    .section-title-box { border:2px solid #000; padding:5px 12px; font-size:14px; font-weight:900; text-transform:uppercase; background:#f8fafc; }
    .meta-mini { font-size:10.5px; color:#334155; font-family:Consolas,monospace; }
    .sub-title { font-size:11px; font-weight:bold; margin:8px 0 4px 0; border-left:3px solid #000; padding-left:6px; text-transform:uppercase; }
    table { width:100%; border-collapse:collapse; margin-bottom:12px; }
    th, td { border:1px solid #999; padding:4px 6px; text-align:left; vertical-align:middle; }
    th { background:#f8fafc; font-weight:bold; font-size:10.5px; }
    td.qte { font-size:14px; font-weight:900; color:#047857; text-align:center; }
    td.support { font-weight:bold; text-align:center; font-size:12px; color:#1d4ed8; }
    td.cuts { font-size:11.5px; font-weight:bold; font-family:Consolas,monospace; line-height:1.6; }
    td.cuts .cut-line { display:block; }
    td.num { text-align:center; font-weight:bold; font-family:Consolas,monospace; }
    td.statut { text-align:center; font-weight:bold; }
    td.statut.stock { color:#047857; }
    td.trace-cell { font-size:10px; color:#1e293b; vertical-align:top; padding:4px 6px; }
    .trace-row { margin-bottom:4px; line-height:1.4; }
    .trace-check { font-size:13px; margin-right:4px; }
    .trace-sig { margin-top:6px; border-top:1px dashed #94a3b8; padding-top:4px; font-style:italic; color:#475569; }
    .global-footer-box { border:2px solid #000; padding:6px 12px; display:flex; justify-content:space-around; font-size:11px; font-weight:bold; margin-top:14px; background:#f8fafc; page-break-inside:avoid; }
    .global-footer-box span.green { color:#047857; }
    .global-footer-box span.red { color:#b91c1c; }
    .global-footer-box span.blue { color:#1e40af; }
  </style>
</head>
<body>
  <div class="header">
    <div class="header-left">
      <h1>Ordre de Fabrication — Fiche de Coupe Débit</h1>
      <div class="meta">Commande : <strong>${cmdAffichee}</strong> | Client : <strong>${clientAffiche}</strong> | Date : ${dateAffichee}</div>
    </div>
    <div class="logo-container" style="text-align:right;">
      <div class="logo-m">TROIS M</div>
      <div class="logo-text">ALUMINIUM</div>
    </div>
  </div>

  <div class="client-info-bar">
    <div>DONNEUR D'ORDRE : <span style="color:#1e40af;">${agenceInfo.nom}</span></div>
    <div>CLIENT FINAL : ${clientAffiche}</div>
    <div>DATE : ${dateAffichee}</div>
  </div>

  ${mailleHTML}
  ${sectionsHTML}

  <div class="global-footer-box">
    <div>BARRES NEUVES : <span class="blue">${totalBarresNeuvesToutesSections} barre(s)</span></div>
    <div>CHUTES UTILISEES : <span class="blue">${totalChutesRecycleesToutesSections}</span></div>
    <div>CHUTES A STOCKER : <span class="green">${totalStockableMm} mm</span></div>
    <div>DECHETS : <span class="red">${totalDechetMm} mm</span></div>
  </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `OF_${cmdAffichee}_${clientAffiche.replace(/\s+/g, '_')}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => window.print();

  /** Émettre l'OF → crée un SuiviOF et bloque le stock */
  const handleEmettreOF = async () => {
    if (ofEmis) return;
    setIsEmitting(true);

    const lignesRetour: LigneRetourOF[] = [];
    let lineId = 1;

    // Générer une ligne de retour pour chaque groupe de barres neuves
    listeSections.forEach(sec => {
      sec.groupesBarresNeuves.forEach(g => {
        for (let i = 0; i < g.quantite; i++) {
          lignesRetour.push({
            id: `lr-${Date.now()}-${lineId++}`,
            repere: g.pieces.map(p => p.repere || p.label || '?').join(', '),
            typeSupport: 'BARRE_NEUVE',
            articleCode: sec.article?.code_art,
            longueurPrevue: g.longueurBarre,
            restePrevuMm: Math.round(g.chute),
            saisieOperateur: '',
          });
        }
      });
      // Générer une ligne de retour pour chaque groupe de chutes récupérées
      sec.groupesChutesRecup.forEach(g => {
        for (let i = 0; i < g.quantite; i++) {
          lignesRetour.push({
            id: `lr-${Date.now()}-${lineId++}`,
            repere: g.pieces.map(p => p.repere || p.label || '?').join(', '),
            typeSupport: 'CHUTE_BARRE',
            articleCode: sec.article?.code_art,
            longueurPrevue: Math.round(g.support),
            restePrevuMm: Math.round(g.reste),
            saisieOperateur: '',
          });
        }
      });
    });

    const today = new Date();
    const dateStr = `${String(today.getDate()).padStart(2,'0')}/${String(today.getMonth()+1).padStart(2,'0')}/${today.getFullYear()}`;

    const validFamille: FamilleProduit =
      famille === 'TABLIER' || famille === 'MOUSTIQUAIRE' || famille === 'CAISSON' || famille === 'PRECADRE'
        ? famille
        : 'CAISSON';

    const suivi: SuiviOF = {
      id: `of-${Date.now()}`,
      numCommande: refCommande || 'CMD',
      nomClient: nomClient || 'CLIENT',
      donneurOrdre: donneurOrdre || '',
      famille: validFamille,
      titreSection: titreProduit || 'Fiche de Coupe',
      statut: 'EMIS',
      dateEmission: dateStr,
      lignesRetour,
      totalBarresNeuvesPrevu: listeSections.reduce((s, sec) => s + (sec.resultat.total_barres_neuves || 0), 0),
      totalChutesUtiliseesPrevu: listeSections.reduce((s, sec) => s + (sec.resultat.total_chutes_recyclees || 0), 0),
    };

    try {
      await StorageService.upsertSuiviOF(suivi);
      setOfEmis(true);
    } catch (error: any) {
      alert(`Impossible d'émettre l'OF : ${error.message}`);
    } finally {
      setIsEmitting(false);
    }
  };

  /* ─── RENDU JSX ─────────────────────────────────────────────── */
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-5xl max-h-[96vh] flex flex-col shadow-2xl text-slate-100 overflow-hidden">

        {/* ── Top Control Bar ── */}
        <div className="px-5 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center text-slate-950 font-black text-xs">3M</div>
            <div>
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <span>Ordre de Fabrication — Fiche de Coupe Débit</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full border font-mono font-bold ${agenceInfo.badgeBg} ${agenceInfo.badgeColor}`}>{agenceInfo.nom}</span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Cmd : <span className="text-amber-400 font-mono font-bold">{cmdAffichee}</span> | Client : <strong className="text-slate-200">{clientAffiche}</strong> | {listeSections.length} section(s)
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={handleDownloadHTML} className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition cursor-pointer">
              <Download className="w-3.5 h-3.5 text-emerald-400" /><span>Exporter HTML</span>
            </button>
            <button onClick={handlePrint} className="px-4 py-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 text-xs font-black rounded-lg flex items-center gap-1.5 transition shadow-sm cursor-pointer">
              <Printer className="w-4 h-4" /><span>Imprimer OF</span>
            </button>
            {/* Bouton Émettre l'OF */}
            <button
              onClick={handleEmettreOF}
              disabled={ofEmis || isEmitting}
              className={`px-4 py-1.5 text-xs font-black rounded-lg flex items-center gap-1.5 transition shadow-sm cursor-pointer border ${
                ofEmis
                  ? 'bg-emerald-900/50 border-emerald-600/50 text-emerald-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white border-sky-500/40'
              }`}
              title={ofEmis ? 'OF déjà émis — en attente de retour opérateur' : 'Émettre l\'OF → Bloque les articles en stock et crée le suivi de retour'}
            >
              {ofEmis ? <CheckCircle2 className="w-4 h-4" /> : <Send className="w-4 h-4" />}
              <span>{ofEmis ? 'OF Émis ✓' : 'Émettre l\'OF'}</span>
            </button>
            <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition ml-1 cursor-pointer">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* ── Paper Sheet ── */}
        <div className="p-4 sm:p-6 overflow-y-auto bg-slate-950/70 font-sans print:bg-white print:text-black">
          <div className="bg-white text-slate-900 p-6 sm:p-8 rounded-xl shadow-xl border border-slate-300 max-w-4xl mx-auto space-y-5 print:p-0 print:border-none print:shadow-none">

            {/* Header */}
            <div className="flex justify-between items-start border-b-2 border-slate-900 pb-3">
              <div>
                <h1 className="text-lg font-black tracking-tight text-slate-900 uppercase">Ordre de Fabrication — Fiche de Coupe Débit</h1>
                <div className="text-xs font-medium text-slate-700 mt-1 font-mono">
                  Commande N° : <strong>{cmdAffichee}</strong> • Client : <strong>{clientAffiche}</strong> • Date : {dateAffichee}
                </div>
              </div>
              <div className="text-right flex items-center gap-2">
                <div className="w-9 h-9 bg-slate-900 rounded flex items-center justify-center text-amber-400 font-black text-base">3M</div>
                <div>
                  <div className="font-black text-xs tracking-wider text-slate-900">TROIS M</div>
                  <div className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">ALUMINIUM</div>
                </div>
              </div>
            </div>

            {/* Info banner — SANS Coloris Global */}
            <div className="grid grid-cols-3 gap-2 bg-slate-100 border border-slate-300 p-2.5 rounded text-xs">
              <div>
                <div className="text-[10px] text-slate-500 uppercase font-bold">Donneur d'Ordre</div>
                <div className="font-bold text-blue-800">{agenceInfo.nom}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500 uppercase font-bold">Client Final</div>
                <div className="font-black text-slate-900">{clientAffiche}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500 uppercase font-bold">Date</div>
                <div className="font-bold text-slate-800">{dateAffichee}</div>
              </div>
            </div>

            {/* ── SECTION 1 : DÉBIT & FAÇONNAGE MAILLE MSTQ (SI COMMANDE MOUSTIQUAIRE) ── */}
            {lignesMoustiquaires && lignesMoustiquaires.filter(m => m.typeFabrication !== 'PROFILES_SEULS').length > 0 && (
              <div className="space-y-3 pt-2">
                <div className="flex items-center gap-3 bg-amber-50 border-2 border-amber-800 py-2 px-4 rounded flex-wrap">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-600 shrink-0"></span>
                  <span className="font-black text-sm text-slate-900 uppercase">🕸️ 1. DÉBIT &amp; FAÇONNAGE MAILLE MSTQ</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded border bg-amber-100 text-amber-800 border-amber-300">
                    Formule validée atelier (+2 plis sécurité)
                  </span>
                </div>
                <div className="border border-slate-400 overflow-hidden rounded">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-400">
                      <tr>
                        <th className="py-1.5 px-2 text-center w-16 border-r border-slate-300">Repère</th>
                        <th className="py-1.5 px-3 border-r border-slate-300">Dim. Finie (L × H)</th>
                        <th className="py-1.5 px-3 border-r border-slate-300">Type Ouverture</th>
                        <th className="py-1.5 px-2 text-center border-r border-slate-300">Coupe Fixe Maille</th>
                        <th className="py-1.5 px-2 text-center border-r border-slate-300">Nb Plis (+2)</th>
                        <th className="py-1.5 px-3 border-r border-slate-300">Guidage &amp; Cordelettes</th>
                        <th className="py-1.5 px-2 text-center border-r border-slate-300">Surface</th>
                        <th className="py-1.5 px-3">Article Maille MSTQ</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-300 font-mono">
                      {lignesMoustiquaires.filter(m => m.typeFabrication !== 'PROFILES_SEULS').map((m, idx) => {
                        const c = calculerBesoinMaille(m);
                        return (
                          <tr key={m.id || idx} className="hover:bg-slate-50">
                            <td className="py-2 px-2 text-center font-black text-amber-800 border-r border-slate-300">{m.repere}</td>
                            <td className="py-2 px-3 font-bold text-slate-900 border-r border-slate-300">{m.largeur} × {m.hauteur} mm (×{m.quantite})</td>
                            <td className="py-2 px-3 font-sans text-xs border-r border-slate-300">
                              {m.typeOuverture === 'PORTE_FENETRE' ? '🚪 Porte-Fenêtre' : m.typeOuverture === 'DOUBLE_VANTAUX' ? '🚪🚪 Baie 2 Vtx' : m.typeOuverture === 'CENTRALE' ? '↔️ Centrale' : m.typeOuverture === 'FIXE' ? '🔒 Fixe' : '🪟 Fenêtre'}
                            </td>
                            <td className="py-2 px-2 text-center font-black text-amber-700 border-r border-slate-300">
                              {c.dimension_fixe_requise} mm <span className="text-[10px] font-normal text-slate-600">({c.dimension_fixe_est === 'H' ? 'Hauteur' : 'Largeur'})</span>
                            </td>
                            <td className="py-2 px-2 text-center font-black text-emerald-700 text-sm border-r border-slate-300">{c.nb_plis_requis} plis</td>
                            <td className="py-2 px-3 text-xs border-r border-slate-300">
                              <div><strong>{c.nb_fils_guidage} fils</strong> (~{c.distance_cordes}mm)</div>
                              <div className="text-purple-700 font-bold">Corde : {c.longueur_corde_totale_m}m ({c.longueur_corde_unitaire_m}m/fil)</div>
                            </td>
                            <td className="py-2 px-2 text-center font-bold text-slate-800 border-r border-slate-300">{c.superficie_m2} m²</td>
                            <td className="py-2 px-3 font-sans text-[11px] text-slate-700">{m.articleDesignationMaille || 'MSTQ MAILLE PLISSÉE 20mm'}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* ── SECTIONS ── */}
            {listeSections.map((sec, sIdx) => {
              const conditionsParts: string[] = [];
              const isCaissonHeader = sec.titre.toUpperCase().includes('CAISSON');
              if (isCaissonHeader) {
                if (sec.avecPeinture) conditionsParts.push('AVEC PEINTURE');
                else conditionsParts.push('SANS PEINTURE');
                if (sec.avecSousFace) {
                  conditionsParts.push(sec.montageSousFace === 'MONTEE_ATELIER' ? 'AVEC MONTAGE' : 'SANS MONTAGE');
                }
              }

              return (
                <div key={sIdx} className={`space-y-3 ${sIdx > 0 ? 'pt-4 border-t-2 border-dashed border-slate-300' : ''}`}>

                  {/* Section header — titre + conditions uniquement pour Caissons, rien pour Sous-Face */}
                  <div className="flex items-center gap-3 bg-slate-100 border-2 border-slate-800 py-2 px-4 rounded flex-wrap">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0"></span>
                    <span className="font-black text-sm text-slate-900 uppercase">{sec.titre}</span>
                    {conditionsParts.map((c, i) => (
                      <span key={i} className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                        c.includes('AVEC PEINTURE') ? 'bg-purple-100 text-purple-800 border-purple-300'
                        : c.includes('AVEC MONTAGE') ? 'bg-sky-100 text-sky-800 border-sky-300'
                        : c.includes('SANS MONTAGE') ? 'bg-amber-100 text-amber-800 border-amber-300'
                        : 'bg-slate-200 text-slate-600 border-slate-300'
                      }`}>{c}</span>
                    ))}
                  </div>

                  {/* BARRES NEUVES */}
                  {sec.groupesBarresNeuves.length > 0 && (
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-1.5 text-xs font-black uppercase text-slate-900">
                        <div className="w-1.5 h-3.5 bg-slate-900"></div>
                        <span>COUPES SUR BARRES NEUVES ({sec.resultat.total_barres_neuves} barre(s))</span>
                        <span className="text-[10px] font-mono text-emerald-700 font-bold ml-auto">Rendement : {sec.resultat.taux_rendement}%</span>
                      </div>
                      <div className="border border-slate-400 overflow-hidden rounded">
                        <table className="w-full text-left text-xs border-collapse">
                          <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-400">
                            <tr>
                              <th className="py-1.5 px-2 text-center w-10 border-r border-slate-300">Qté</th>
                              <th className="py-1.5 px-3 border-r border-slate-300">Mesures à Couper (avec Repère)</th>
                              <th className="py-1.5 px-2 text-center w-20 border-r border-slate-300">Reste</th>
                              <th className="py-1.5 px-2 text-center w-20 border-r border-slate-300">Ce reste</th>
                              <th className="py-1.5 px-3">Nouvelle chute</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-300">
                            {sec.groupesBarresNeuves.map((g, i) => (
                              <tr key={i} className="hover:bg-slate-50">
                                <td className="py-2 px-2 text-center font-black text-base text-emerald-800 border-r border-slate-300 font-mono">{g.quantite}</td>
                                <td className="py-2 px-3 font-mono font-bold text-xs border-r border-slate-300">
                                  <div className="space-y-0.5">
                                    {g.pieces.map((p, pIdx) => (
                                      <div key={pIdx} className="text-slate-900 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-300">{formaterCoupe(p)}</div>
                                    ))}
                                  </div>
                                </td>
                                <td className="py-2 px-2 text-center font-mono font-bold text-slate-800 border-r border-slate-300">{Math.round(g.chute)}</td>
                                <td className="py-2 px-2 text-center font-bold text-xs border-r border-slate-300">
                                  <span className={g.statut === 'STOCK' ? 'text-emerald-700' : 'text-slate-500'}>
                                    {g.statut === 'STOCK' ? 'A STOCKER' : 'DECHET'}
                                  </span>
                                </td>
                                <td className="py-2 px-3 text-xs text-slate-400 italic font-mono">................................</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {/* CHUTES RÉCUPÉRÉES */}
                  {sec.groupesChutesRecup.length > 0 && (
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-1.5 text-xs font-black uppercase text-slate-900">
                        <div className="w-1.5 h-3.5 bg-sky-700"></div>
                        <span>COUPES SUR CHUTES DU STOCK ({sec.resultat.total_chutes_recyclees} chute(s))</span>
                      </div>
                      <div className="border border-slate-400 overflow-hidden rounded">
                        <table className="w-full text-left text-xs border-collapse">
                          <thead className="bg-sky-50 text-slate-800 font-bold border-b border-slate-400">
                            <tr>
                              <th className="py-1.5 px-2 text-center w-10 border-r border-slate-300">Qté</th>
                              <th className="py-1.5 px-2 text-center w-24 border-r border-slate-300">Chute prévue</th>
                              <th className="py-1.5 px-3 border-r border-slate-300">Mesures à Couper (avec Repère)</th>
                              <th className="py-1.5 px-2 text-center w-20 border-r border-slate-300">Reste</th>
                              <th className="py-1.5 px-3">Nouvelle chute</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-300">
                            {sec.groupesChutesRecup.map((g, i) => (
                              <tr key={i} className="hover:bg-sky-50/30">
                                <td className="py-2 px-2 text-center font-black text-base text-sky-800 border-r border-slate-300 font-mono">{g.quantite}</td>
                                <td className="py-2 px-2 text-center font-mono font-bold text-sky-900 border-r border-slate-300">{Math.round(g.support)} mm</td>
                                <td className="py-2 px-3 font-mono font-bold text-xs border-r border-slate-300">
                                  <div className="space-y-0.5">
                                    {g.pieces.map((p, pIdx) => (
                                      <div key={pIdx} className="text-slate-900 bg-sky-50 px-1.5 py-0.5 rounded border border-sky-300">{formaterCoupe(p)}</div>
                                    ))}
                                  </div>
                                </td>
                                <td className="py-2 px-2 text-center font-mono font-bold text-slate-800 border-r border-slate-300">{Math.round(g.reste)}</td>
                                <td className="py-2 px-3 text-xs text-slate-400 italic font-mono">................................</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {/* Bilan global */}
            <div className="border-2 border-slate-900 py-2.5 px-4 flex flex-wrap justify-between items-center font-black text-xs uppercase bg-slate-50 gap-2">
              <div>BARRES NEUVES : <span className="text-blue-800 font-mono text-sm">{totalBarresNeuvesToutesSections}</span></div>
              <div>CHUTES UTILISEES : <span className="text-blue-800 font-mono text-sm">{totalChutesRecycleesToutesSections}</span></div>
              <div>CHUTES A STOCKER : <span className="text-emerald-700 font-mono text-sm">{totalStockableMm} mm</span></div>
              <div>DECHETS RESIDUELS : <span className="text-rose-700 font-mono text-sm">{totalDechetMm} mm</span></div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};
