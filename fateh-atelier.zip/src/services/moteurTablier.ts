import { CommandeTablier, PieceACouper } from '../types';

export function calculerNbLame(hauteur: number, hauteurLameTablier: number): number {
  if (hauteurLameTablier <= 0) {
    throw new Error('La hauteur de lame de tablier doit être supérieure à 0');
  }
  // Règle validée par l'atelier (§9) : arrondi supérieur direct (Math.ceil) sans marge additionnelle
  return Math.ceil(hauteur / hauteurLameTablier);
}

export function calculerTablier(commande: CommandeTablier): {
  commande: CommandeTablier;
  nbLame: number;
  longueurLame: number; // = Largeur
  totalLames: number;   // nbLame * quantite
  piecesLames: { longueur: number; quantite: number; label: string; repere: string; refCommande?: string }[];
} {
  const nbLame = calculerNbLame(commande.hauteur, commande.hauteur_lame_tablier);
  const totalLames = nbLame * Math.max(1, commande.quantite);
  
  // Format repère propre : e.g. "1R2" ou "1R2 (Cmd: S-A26698)"
  const repereCode = commande.repere.trim() || 'Tablier';
  const label = commande.refCommande ? `${repereCode} [${commande.refCommande}]` : repereCode;

  const piecesLames = [
    {
      longueur: commande.largeur,
      quantite: totalLames,
      label,
      repere: repereCode,
      refCommande: commande.refCommande
    }
  ];

  return {
    commande: { ...commande, nb_lame: nbLame },
    nbLame,
    longueurLame: commande.largeur,
    totalLames,
    piecesLames
  };
}

export function fusionnerCommandesTablier(
  resultatsTabliers: { piecesLames: { longueur: number; quantite: number; label: string; repere: string; refCommande?: string }[] }[]
): { longueur: number; quantite: number; label: string; repere: string; refCommande?: string }[] {
  const pool: { longueur: number; quantite: number; label: string; repere: string; refCommande?: string }[] = [];
  for (const res of resultatsTabliers) {
    pool.push(...res.piecesLames);
  }
  return pool;
}
