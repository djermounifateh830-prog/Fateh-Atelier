import { ModeDebordementPrecadre } from '../types';

export const getDimensionsPrecadrePiece = (
  largeur: number,
  hauteur: number,
  modeDebordement: ModeDebordementPrecadre,
  debSup: number = 100,
  debInf: number = 300,
  deductionBouchonParCote: number = 10
) => {
  let addHaut = 0;
  let addBas = 0;
  if (modeDebordement === 'SUPERIEUR_INFERIEUR' || (modeDebordement as any) === 'DOUBLE') {
    addHaut = debSup;
    addBas = debInf;
  } else if (modeDebordement === 'SUPERIEUR_SEUL' || (modeDebordement as any) === 'SUPERIEUR') {
    addHaut = debSup;
  } else if (modeDebordement === 'INFERIEUR_SEUL' || (modeDebordement as any) === 'INFERIEUR') {
    addBas = debInf;
  }

  const sommeDebordements = addHaut + addBas;
  const hasDebordement = sommeDebordements > 0;
  const typeAssemblage: 'BOUCHON' | 'EQUERRE' = hasDebordement ? 'EQUERRE' : 'BOUCHON';
  const dedBouchon = typeAssemblage === 'BOUCHON' ? Math.abs(deductionBouchonParCote) : 0;

  // 1. Traverses horizontales (TRH + TRB) : Toujours L - 20 mm (fixe, avec ou sans débordement)
  const lTraverse = Math.max(0, largeur - 20);

  // 2. Montants verticaux extérieurs (2 × MT) :
  // - Sans débordement : H - 20 mm (ou H - 2 * dedBouchon)
  // - Avec débordement : H (exactement H, sans ajout des débordements ni déduction)
  const hMontant = hasDebordement
    ? hauteur
    : Math.max(0, hauteur - 2 * dedBouchon);

  // 3. Renfort horizontal seul L1 : L - 20 mm
  const lRenfortSeul = Math.max(0, largeur - 20);

  // 4. Demi-renfort horizontal L1 (pour renfort croisé L1 + H1) : (L - 30) / 2 mm
  const lDemiRenfortCroise = Math.max(0, Math.round(((largeur - 30) / 2) * 10) / 10);

  // 5. Renfort vertical H1 (seul ou croisé) : H - sommeDebordements - 20 mm
  const hRenfort = Math.max(0, hauteur - sommeDebordements - 20);

  return {
    hMontant,
    lTraverse,
    lRenfortSeul,
    lDemiRenfortCroise,
    hRenfort,
    typeAssemblage,
    hasDebordement,
    addHaut,
    addBas,
    sommeDebordements
  };
};
